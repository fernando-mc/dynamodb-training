var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'workshop',
applicationName: 'ddb-stream-outputs',
appUid: 'ysR05MQjm4K8Psly4j',
tenantUid: 'PDy2pRdVrB76Br6Ksv',
deploymentUid: '89ec01f3-16be-48d5-ada9-d4f39243e87d',
serviceName: 'service-with-stream-reader',
stageName: 'dev',
pluginVersion: '3.2.1'})
const handlerWrapperArgs = { functionName: 'service-with-stream-reader-dev-streamProcessor', timeout: 6}
try {
  const userHandler = require('./streamHandler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
