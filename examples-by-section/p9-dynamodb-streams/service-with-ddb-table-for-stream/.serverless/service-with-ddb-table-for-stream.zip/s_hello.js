var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'workshop',
applicationName: 'ddb-stream-outputs',
appUid: 'ysR05MQjm4K8Psly4j',
tenantUid: 'PDy2pRdVrB76Br6Ksv',
deploymentUid: 'e721b334-fe96-43a9-a168-2dfce203c555',
serviceName: 'service-with-ddb-table-for-stream',
stageName: 'dev',
pluginVersion: '3.2.1'})
const handlerWrapperArgs = { functionName: 'service-with-ddb-table-for-stream-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
