var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'workshop',
applicationName: 'simple-ddb-table-app',
appUid: 'TNPLRXl4Zv1xDMxrGC',
tenantUid: 'PDy2pRdVrB76Br6Ksv',
deploymentUid: '7a6aed6e-c4b8-474a-893f-efa254853bb2',
serviceName: 'simple-ddb-table',
stageName: 'prod',
pluginVersion: '3.2.1'})
const handlerWrapperArgs = { functionName: 'simple-ddb-table-prod-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
